from core.splash_ast import *


class Optimizer():
    """
        - Dead Code Elimination         
    """
    

    
    
